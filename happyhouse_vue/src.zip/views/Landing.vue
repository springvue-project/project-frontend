<template>
  <div class="wrapper">
    <parallax class="section page-header header-filter" :style="headerStyle">
      <div class="container">
        <div class="md-layout">
          <div
            class="md-layout-item md-size-50 md-small-size-70 md-xsmall-size-100"
          >
            <h1 class="title">Your Story Starts With Us.</h1>
            <h4>
              Every landing page needs a small description after the big bold
              title, that's why we added this text here. Add here all the
              information that can make you or your product create the first
              impression.
            </h4>
            <br />
            <md-button
              href="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
              class="md-success md-lg"
              target="_blank"
              ><i class="fas fa-play"></i> Watch video</md-button
            >
          </div>
        </div>
      </div>
    </parallax>
    <div>
      <div class="card-body">
        <div class="form-group form-inline justify-content-center">
          <label class="mr-2" for="sido">시도 : </label>
          <select class="form-control" id="sido">
            <option value="0">선택</option>
          </select>
          <label class="mr-2 ml-3" for="gugun">구군 : </label>
          <select class="form-control" id="gugun">
            <option value="0">선택</option>
          </select>
          <label class="mr-2 ml-3" for="dong">읍면동 : </label>
          <select class="form-control" id="dong">
            <option value="0">선택</option>
          </select>
        </div>
        <div class="center">
          <span class="text-center" id="spantext"> </span>
        </div>
        <table class="table mt-2">
          <colgroup>
            <col width="150" />
            <col width="*" />
            <col width="70" />
            <col width="70" />
            <col width="100" />
            <col width="150" />
          </colgroup>
          <thead>
            <tr>
              <th>주차장명</th>
              <th>주소</th>
              <th>구분</th>
              <th>요금</th>
              <th>주차대수</th>
              <th>연락처</th>
            </tr>
          </thead>
          <tbody id="searchResult"></tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  bodyClass: "landing-page",
  props: {
    header: {
      type: String,
      default: require("@/assets/img/bg7.jpg"),
    },
    teamImg1: {
      type: String,
      default: require("@/assets/img/faces/avatar.jpg"),
    },
    teamImg2: {
      type: String,
      default: require("@/assets/img/faces/christian.jpg"),
    },
    teamImg3: {
      type: String,
      default: require("@/assets/img/faces/kendall.jpg"),
    },
  },
  data() {
    return {
      name: null,
      email: null,
      message: null,
    };
  },
  computed: {
    headerStyle() {
      return {
        backgroundImage: `url(${this.header})`,
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.md-card-actions.text-center {
  display: flex;
  justify-content: center !important;
}
.contact-form {
  margin-top: 30px;
}

.md-has-textarea + .md-layout {
  margin-top: 15px;
}
</style>
